import datetime
import mysql
import random
from flask import Flask, render_template, request, redirect, url_for,session
import pymysql
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps













# Създаване на Flask приложение
app = Flask(__name__)

# Функция за установяване на връзка с MySQL базата данни
def get_db_connection():
    return pymysql.connect(host='localhost',
                           user='root',
                           password='1234',
                           database='air_transport_system_db',
                           cursorclass=pymysql.cursors.DictCursor)




# Декоратор за проверка дали администратор е логнат
def admin_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not session.get("admin_logged_in"):
            return redirect(url_for("admin_login"))
        return func(*args, **kwargs)
    return wrapper


# Функция за вход на администратор
@app.route("/admins/login", methods=["GET", "POST"])
def admin_login():

    if request.method == "POST":
        username = request.form.get("username")   # вземане на данни от форма с (request.form.get)
        password = request.form.get("password")

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM admins WHERE username = %s AND password = %s", (username, password))
        admin = cursor.fetchone()

        cursor.close()
        conn.close()

        if admin:
            session["admin_logged_in"] = True
            session["admin_id"] = admin['id']
            return redirect(url_for("admin_dashboard"))
        else:

            return redirect(url_for("index") + "?error=invalid_credentials")




# Табло на администратора
@app.route("/admins/dashboard")
@admin_required
def admin_dashboard():
    return render_template("Admin_templates/admin_dashboard.html")








# Функция за изход от системата (за администратор или пътник)
@app.route("/logout") # маршрут - @app route
def logout():
    session.pop("admin_logged_in", None)
    return redirect(url_for('index'))




# Функция за начална страница
@app.route("/")
def index():
    return render_template("index.html")

# Функция за добавяне на нов самолет
@app.route('/add_aircraft', methods=['GET', 'POST'])
@admin_required
def add_aircraft():
    if request.method == 'POST':
        model = request.form.get('model')
        capacity = request.form.get('capacity')
        registration_number = request.form.get('registration_number')
        status = request.form.get('status')

        connection = get_db_connection()  # свързване с базата чрез conn = get_db_connection(),
                                          # cursor = conn.cursor()
        cursor = connection.cursor()
        cursor.execute("INSERT INTO aircraft (model, capacity, registration_number, status) VALUES (%s, %s, %s, %s)",
                       (model, capacity, registration_number, status))
        connection.commit()
        cursor.close()
        connection.close()

        return redirect(url_for('review_and_manage_aircraft'))

    return render_template('Aircraft_templates/add_aircraft.html')






# Функция за редактиране на самолет
@app.route("/aircraft/edit/<int:id>", methods=["GET", "POST"])
@admin_required
def edit_aircraft(id):
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("SELECT * FROM aircraft WHERE id = %s", (id,))
    aircraft = cursor.fetchone()

    if request.method == "POST":
        model = request.form.get("model")
        capacity = request.form.get("capacity")
        registration_number = request.form.get("registration_number")
        status = request.form.get("status")

        cursor.execute("""
            UPDATE aircraft 
            SET model = %s, capacity = %s, registration_number = %s, status = %s 
            WHERE id = %s
        """, (model, capacity, registration_number, status, id))          # изпълнение на заявка към базата данни чрез cursor.execute()

        connection.commit()
        cursor.close()
        connection.close()

        return redirect(url_for("review_and_manage_aircraft"))

    cursor.close()
    connection.close()
    return render_template("Aircraft_templates/edit_aircraft.html", aircraft=aircraft)

# Функция за преглед и управление на всички самолети
@app.route('/aircraft')
@admin_required
def review_and_manage_aircraft():
    connection = get_db_connection()
    cursor = connection.cursor()



    status_filter = request.args.get("status")

    if status_filter:
        cursor.execute("SELECT * FROM aircraft WHERE status = %s", (status_filter,))
    else:
        cursor.execute("SELECT * FROM aircraft")

    aircraft = cursor.fetchall()  # обработка на резултати чрез cursor.fetchall()


    cursor.close()
    connection.close()
    return render_template('Aircraft_templates/review_and_manage_aircraft.html', aircraft=aircraft, status_filter=status_filter)





# Функция за изтриване на самолет
@app.route("/aircraft/<int:id>", methods=["POST"])
@admin_required
def delete_aircraft(id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM aircraft WHERE id = %s", (id,))
    conn.commit()

    cursor.close()
    conn.close()

    return redirect(url_for("review_and_manage_aircraft"))

# Функция за вход за пътници
@app.route("/passengers/login", methods=["GET", "POST"])
def passenger_login():
    passenger = None
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        cursor = get_db_connection().cursor()
        cursor.execute("SELECT * FROM passengers WHERE email = %s AND password = %s", (email, password))
        passenger= cursor.fetchone()  # връщане на един ред от резултата чрез cursor.fetchone()

        # проверки if/else
    if passenger:
        session["passenger_id"] = passenger['id']# ID-то на пътника
        session["passenger_name"] = passenger['name'] # Името
        return redirect(url_for("passenger_dashboard"))
    else:

        return redirect(url_for("index", error="invalid_passenger_credentials"))









# Функция за изход на пътник
@app.route("/passengers/logout")
def passenger_logout():
    session.pop("passenger_id", None)
    session.pop("passenger_name", None)
    return redirect(url_for('index'))



# Табло на пътника
@app.route("/passengers/dashboard")
def passenger_dashboard():
    if "passenger_id" not in session:
        return redirect(url_for("passenger_login"))

    return render_template("Passenger_templates/passenger_dashboard.html", passenger_name=session["passenger_name"])

# Функция за управление на всички пътници (само за администратор)
@app.route("/admin/manage_passengers")
@admin_required
def manage_passengers():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM passengers")
    passengers = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template("Passenger_templates/manage_passengers.html", passengers=passengers)


# Функция за  регистрация на нов пътник
@app.route("/passengers/register", methods=["GET", "POST"])
def register_passenger():
    if request.method == "POST":
        name = request.form.get("name")
        last_name = request.form.get("last_name")
        email = request.form.get("email")
        password = request.form.get("password")
        phone = request.form.get("phone")
        document_number = request.form.get("document_number")

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
                  INSERT INTO passengers (name,last_name, email,password,phone, document_number) 
                  VALUES (%s, %s,%s, %s,%s,%s)
              """, (name,last_name, email,password,phone, document_number))
        conn.commit()

        passenger_id = cursor.lastrowid

        session["passenger_id"] = passenger_id
        session["passenger_name"] = name


        cursor.close()
        conn.close()

        return redirect(url_for("passenger_dashboard"))

    return render_template("Passenger_templates/register_passengers.html")


# Функция за изтриване на пътник(само за администратор)
@app.route("/admin/passengers/<int:id>")
@admin_required
def delete_passenger(id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM passengers WHERE id = %s", (id,))
    conn.commit()

    cursor.close()
    conn.close()

    return redirect(url_for("manage_passengers"))  # пренасочване с redirect()



#  Функция за създаване на резервация от пътник
@app.route("/passengers/reservations", methods=["GET", "POST"])
def create_reservation():

    passenger_id = session["passenger_id"]  # Взимаме ID-то на логнатия пътник

    conn = get_db_connection()
    cursor = conn.cursor()


    cursor.execute("""
               SELECT flights.id, flights.flight_number, flights.status, flights.departure_city, aircraft.capacity
               FROM flights
               JOIN aircraft ON flights.aircraft = aircraft.id
               WHERE aircraft.capacity < 1000 AND flights.status = 'Планиран'
           """)
    flights = cursor.fetchall()






    if request.method == "POST":
        flight_id = request.form.get("flight_id")
        seat_number = request.form.get("seat_number")
        status = request.form.get("status")

        cursor.execute("""
                SELECT * FROM reservations WHERE flight_id = %s AND seat_number = %s
            """, (flight_id, seat_number))
        existing = cursor.fetchone()

        cursor.execute("SELECT COUNT(*) AS reserved FROM reservations WHERE flight_id = %s", (flight_id,))
        reserved = cursor.fetchone()["reserved"]

        cursor.execute(
            "SELECT aircraft.capacity FROM flights JOIN aircraft ON flights.aircraft = aircraft.id WHERE flights.id = %s",
            (flight_id,))
        capacity = cursor.fetchone()["capacity"]

        if reserved >= capacity:
            return redirect(url_for("create_reservation", error="no_seats_available"))



      #проверка за заето място
        if existing:
            return redirect(url_for("create_reservation", error="seat_taken"))


        cursor.execute("""
            INSERT INTO reservations (passenger_id, flight_id, seat_number, status) 
            VALUES (%s, %s, %s, %s)
        """, (passenger_id, flight_id, seat_number, status))
        conn.commit()
        cursor.close()                  # затваряне на връзката  чрез  cursor.close() и
                                          #conn.close()
        conn.close()

        return redirect(url_for("passenger_dashboard"))

    # зареждане  на HTML шаблон и подаване на данни към тях чрез render_template()
    return render_template("Reservation_templates/create_reservations.html", flights=flights)



# Управление на резервации



# Функция за генериране на случаен статус на резервации
@app.route('/randomize_reservation_status', methods=['POST'])
@admin_required
def randomize_reservation_status():
    connection = get_db_connection()
    cursor = connection.cursor()

    # Обновяване на всички резервации със случаен статус
    cursor.execute("SELECT id FROM reservations")
    reservations = cursor.fetchall()

    for res in reservations:
        new_status = random.choice(['потвърдена', 'анулирана'])
        cursor.execute("UPDATE reservations SET status = %s WHERE id = %s", (new_status, res['id']))

    connection.commit()
    cursor.close()
    connection.close()


    return redirect(url_for('manage_reservations'))












# Функция за управление на резервации от администратор
@app.route("/reservations")
@admin_required
def manage_reservations():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
       SELECT 
        r.id, 
        CONCAT(p.name, ' ', p.last_name) AS passenger_name, 
        f.flight_number, 
        r.seat_number, 
        r.status 
    FROM reservations r
    JOIN passengers p ON r.passenger_id = p.id
    JOIN flights f ON r.flight_id = f.id;

    """)
    reservations = cursor.fetchall()

    cursor.close()
    conn.close()
    return render_template("Reservation_templates/manage_reservations.html", reservations=reservations)


# Функция за актуализиране на резервации от администратор
@app.route("/reservations/<int:id>", methods=["GET", "POST"])
@admin_required
def update_reservation(id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
            SELECT reservations.*,CONCAT(passengers.name, ' ', passengers.last_name) AS passenger_name,  flights.flight_number 
            FROM reservations 
            JOIN flights ON reservations.flight_id = flights.id 
             JOIN passengers  ON reservations.passenger_id = passengers.id
            WHERE reservations.id = %s
        """, (id,))
    reservations = cursor.fetchone()

    if request.method == "POST":
        seat_number = request.form.get("seat_number")
        status = request.form.get("status")

        cursor.execute("""
            UPDATE reservations SET seat_number = %s , status = %s WHERE id = %s
        """, (seat_number, status, id))
        conn.commit()

        return redirect(url_for("manage_reservations"))

    cursor.close()
    conn.close()
    return render_template("Reservation_templates/update_reservations.html", reservations=reservations)

# Функция за изтриване на резервации от администратор
@app.route("/reservations/delete/<int:id>", methods=["POST"])
@admin_required
def delete_reservation(id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM reservations WHERE id = %s", (id,))
    conn.commit()

    cursor.close()
    conn.close()

    return redirect(url_for("manage_reservations"))


@app.route("/passengers/my_reservations")
def my_reservations():
    if "passenger_id" not in session:
        return redirect(url_for("passenger_login"))

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT reservations.*, flights.flight_number
        FROM reservations
        JOIN flights ON reservations.flight_id = flights.id
        WHERE passenger_id = %s
    """, (session["passenger_id"],))
    reservations = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template("Passenger_templates/my_reservations.html", reservations=reservations)


@app.route("/flights/add_flights", methods=["GET", "POST"])
@admin_required
def add_flights():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT id, model, status FROM aircraft")
    aircrafts = cursor.fetchall()



    if request.method == "POST":
        flight_number = request.form.get("flight_number")
        departure = request.form.get("departure")
        arrival = request.form.get("arrival")
        aircraft = request.form.get("aircraft")
        crew = request.form.get("crew")
        departure_city = request.form.get("departure_city")
        arrival_city = request.form.get("arrival_city")
        status = request.form.get("status")



        cursor.execute(
            "INSERT INTO flights (flight_number, departure, arrival, aircraft, crew, status ,departure_city, arrival_city) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
            (flight_number, departure, arrival, aircraft, crew, status,departure_city,arrival_city)
        )
        conn.commit()
        return redirect(url_for("manage_flights", created="true"))

    cursor.execute("SELECT * FROM flights")
    flights = cursor.fetchall()





    cursor.close()
    conn.close()



    return render_template("Flight_templates/add_flights.html", flights=flights, aircrafts=aircrafts)



@app.route("/flights/edit/<int:id>", methods=["GET", "POST"])
@admin_required
def edit_flight(id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM flights WHERE id = %s", (id,))
    flight = cursor.fetchone()

    cursor.execute("SELECT id, model FROM aircraft")
    aircrafts = cursor.fetchall()

    if request.method == "POST":
        # Вземане на новите стойности
        flight_number = request.form.get("flight_number")
        departure = request.form.get("departure")
        arrival = request.form.get("arrival")
        aircraft = request.form.get("aircraft")
        crew = request.form.get("crew")
        status = request.form.get("status")
        departure_city = request.form.get("departure_city")
        arrival_city = request.form.get("arrival_city")

        cursor.execute("""
            UPDATE flights
            SET flight_number=%s, departure=%s, arrival=%s, aircraft=%s, crew=%s,
                status=%s, departure_city=%s, arrival_city=%s
            WHERE id=%s
        """, (flight_number, departure, arrival, aircraft, crew, status,
              departure_city, arrival_city, id))
        conn.commit()
        return redirect(url_for("manage_flights"))

    return render_template("Flight_templates/edit_flight.html", flight=flight, aircrafts=aircrafts)




@app.route("/flights")
@admin_required
def manage_flights():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT flights.id, flights.flight_number, flights.departure_city, flights.arrival_city, 
               flights.departure, flights.arrival, 
               CONCAT(aircraft.id, ' - ', aircraft.model) AS aircraft_info, 
               flights.crew, flights.status 
        FROM flights
        JOIN aircraft ON flights.aircraft = aircraft.id
    """)
    flights = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template("Flight_templates/manage_flights.html", flights=flights)



@app.route("/flights/delete/<int:id>", methods=["POST"])
@admin_required
def delete_flight(id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM flights WHERE id = %s", (id,))
    conn.commit()

    cursor.close()
    conn.close()

    return redirect(url_for("manage_flights"))


@app.route("/cargo", methods=["GET", "POST"])
@admin_required
def add_cargo():
    conn = get_db_connection()
    cursor = conn.cursor()

    if request.method == "POST":
        description = request.form.get("description")
        weight =  request.form.get("weight")
        volume = request.form.get("volume")
        flight_id = request.form.get("flight_id")
        status = request.form.get("status")
        location = request.form.get("location")






        cursor.execute("""
               INSERT INTO cargo (description, weight, volume, flight_id, status, location) 
               VALUES (%s, %s, %s, %s, %s, %s)
           """, (description, weight, volume, flight_id, status, location))

        conn.commit()

    cursor.execute("SELECT * FROM cargo")
    cargo_list = cursor.fetchall()

    cursor.execute("""
           SELECT flights.id, flights.flight_number, flights.status, flights.departure_city, aircraft.capacity
           FROM flights
           JOIN aircraft ON flights.aircraft = aircraft.id
           WHERE aircraft.capacity > 1000 AND flights.status = 'Планиран'
       """)
    flights = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template("Cargo_templates/add_cargo.html", cargo_list=cargo_list, flights=flights)


@app.route("/cargo<int:id>", methods=["GET", "POST"])
@admin_required
def edit_cargo(id):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Взимаме текущите данни за товара
    cursor.execute("SELECT * FROM cargo WHERE id = %s", (id,))
    cargo = cursor.fetchone()



    if request.method == "POST":
        description = request.form.get("description")
        weight = request.form.get("weight")
        volume = request.form.get("volume")
        flight_id = request.form.get("flight_id")
        status = request.form.get("status")
        location = request.form.get("location")


        cursor.execute("""
            UPDATE cargo 
            SET description = %s, weight = %s, volume = %s, flight_id = %s, status = %s, location = %s
            WHERE id = %s
        """, (description, weight, volume, flight_id, status, location, id))

        conn.commit()
        cursor.close()
        conn.close()

        return redirect(url_for("manage_cargo"))

    cursor.close()
    conn.close()
    return render_template("Cargo_templates/edit_cargo.html", cargo=cargo)


@app.route("/cargo/<int:id>/status", methods=["POST"])
@admin_required
def track_cargo(id):
    connection = get_db_connection()
    cursor = connection.cursor()


    cursor.execute("""
        SELECT c.status, f.arrival_city
        FROM cargo c
        JOIN flights f ON c.flight_id = f.id
        WHERE c.id = %s
    """, (id,))
    track = cursor.fetchone()

    if track:
        current_status = track['status']
        arrival_city = track['arrival_city']



        if current_status == "Очаква товарене":
            new_status = "В движение"
            new_location = None
            cursor.execute("""
                UPDATE cargo SET status=%s, location=%s WHERE id=%s
            """, (new_status, new_location, id))

        elif current_status == "В движение":
            new_status = "Доставено"
            new_location = arrival_city
            cursor.execute("""
                UPDATE cargo SET status=%s, location=%s WHERE id=%s
            """, (new_status, new_location, id))

        elif current_status == "Доставено":
            cursor.execute("DELETE FROM cargo WHERE id=%s", (id,))

        connection.commit()


    cursor.close()
    connection.close()
    return redirect(url_for("manage_cargo"))


@app.route("/manage_cargo")
@admin_required
def manage_cargo():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT cargo.id, cargo.description, cargo.weight, cargo.volume, cargo.status, cargo.location ,
               CONCAT('Полет № ', flights.flight_number) AS flight_display
        FROM cargo
        JOIN flights ON cargo.flight_id = flights.id
    """)
    cargo_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template("Cargo_templates/manage_cargo.html", cargo_list=cargo_list)


@app.route("/cargo/<int:id>/update_status", methods=["POST"])
@admin_required
def update_cargo_status(id):
    new_status = request.form.get("status")

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE cargo SET status = %s WHERE id = %s", (new_status, id))
    conn.commit()
    cursor.close()
    conn.close()

    return redirect(url_for("manage_cargo"))








@app.route("/cargo/delete/<int:id>", methods=["POST"])
@admin_required
def delete_cargo(id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM cargo WHERE id = %s", (id,))
    conn.commit()

    cursor.close()
    conn.close()

    return redirect(url_for("manage_cargo"))






if __name__ == "__main__":
    app.secret_key = "viktor_secret_key" # Настройки за сесиите (необходим е таен ключ за управление на потребителски сесии)
    app.run(debug=True)