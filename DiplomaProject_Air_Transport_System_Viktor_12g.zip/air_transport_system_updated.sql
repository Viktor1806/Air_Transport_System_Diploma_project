-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: air_transport_system_db
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (21,'admin','admin123');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aircraft`
--

DROP TABLE IF EXISTS `aircraft`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aircraft` (
  `id` int NOT NULL AUTO_INCREMENT,
  `model` varchar(50) NOT NULL,
  `registration_number` varchar(20) NOT NULL,
  `capacity` int NOT NULL,
  `status` enum('Изправен','Неизправен','В ремонт') NOT NULL DEFAULT 'Изправен',
  PRIMARY KEY (`id`),
  UNIQUE KEY `registration_number` (`registration_number`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aircraft`
--

LOCK TABLES `aircraft` WRITE;
/*!40000 ALTER TABLE `aircraft` DISABLE KEYS */;
INSERT INTO `aircraft` VALUES (1,'Airbus A310 - пътнически','BC173AP86',150,'Изправен'),(5,' Boeing 737 - пътнически','N123AB',200,'Неизправен'),(6,'Airbus A300  - пътнически','EC-KLM ',400,'В ремонт'),(7,'Boeing 767  - пътнически','F-GLXY',250,'Изправен'),(8,'McDonnell Douglas MD-11  - пътнически','D-AEXX ',360,'Неизправен'),(9,'Ilyushin Il-76 - товарен','LX-TXA',50000,'Изправен'),(10,'Antonov An-124 Ruslan - товарен','TF-LLC',150000,'Изправен'),(11,'Douglas DC-8F - товарен','9V-STP',50000,'Неизправен'),(12,'Lockheed L-100 Hercules - товарен','F-HOXX ',20000,'Изправен'),(13,' Boeing 767-300F - товарен','EI-FAA ',59000,'Изправен'),(14,'Airbus A319 - пътнически','A319-XYZ',140,'Неизправен'),(15,'Boeing 747-8F - товарен','B747F-MNB',140000,'Изправен'),(16,'Boeing 757 - пътнически',' B757-ABC',230,'Изправен'),(17,'Antonov An-225 Mriya - товарен','AN225-HJK',250000,'Неизправен'),(18,'Embraer E195 - пътнически','E195-LMN',120,'В ремонт'),(19,'Lockheed C-130 Hercules - товарен','C130-PLM',20000,'Изправен'),(20,'Bombardier CS300 - пътнически','CS300-QWE',145,'Изправен'),(21,'Boeing 737-800BCF - товарен',' B737BCF-YUI',23000,'Изправен'),(22,'Tupolev Tu-204 - пътнически','TU204-RTY',210,'Изправен'),(23,'McDonnell Douglas MD-10F - товарен','MD10F-OPQ',65000,'Неизправен'),(24,'Airbus A330 - пътнически','A330-ZXC',277,'В ремонт'),(25,'Ilyushin Il-96T - товарен','IL96T-WER',92000,'Изправен'),(26,'Boeing 777 - пътнически','B777-ASD',396,'Неизправен'),(27,'Airbus A310-300F - товарен','A310F-TYU',88000,'Изправен'),(28,'McDonnell Douglas DC-10 - пътнически ','DC10-UIO',270,'Изправен'),(29,'Embraer E190F - товарен','E190F-BVC',14000,'Неизправен'),(30,'Sukhoi Superjet 100 - пътнически','SSJ100-JKL',98,'В ремонт'),(31,'Tupolev Tu-330 - товарен',' TU330-NHG',100000,'Изправен'),(32,'Comac C919 - пътнически','C919-DFG',158,'Неизправен'),(33,'Antonov An-12 - товарен ',' AN12-KLM',20000,'Изправен');
/*!40000 ALTER TABLE `aircraft` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cargo`
--

DROP TABLE IF EXISTS `cargo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cargo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` text NOT NULL,
  `weight` float NOT NULL,
  `volume` float NOT NULL,
  `flight_id` int NOT NULL,
  `status` varchar(50) DEFAULT 'В процес',
  `location` varchar(100) DEFAULT 'Склад',
  PRIMARY KEY (`id`),
  KEY `flight_id` (`flight_id`),
  CONSTRAINT `cargo_ibfk_1` FOREIGN KEY (`flight_id`) REFERENCES `flights` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cargo`
--

LOCK TABLES `cargo` WRITE;
/*!40000 ALTER TABLE `cargo` DISABLE KEYS */;
INSERT INTO `cargo` VALUES (16,'морски дарове',40000,90,34,'Очаква товарене','Склад');
/*!40000 ALTER TABLE `cargo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flights`
--

DROP TABLE IF EXISTS `flights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flights` (
  `id` int NOT NULL AUTO_INCREMENT,
  `flight_number` varchar(20) NOT NULL,
  `departure` datetime NOT NULL,
  `arrival` datetime NOT NULL,
  `aircraft` varchar(50) NOT NULL,
  `crew` text NOT NULL,
  `status` enum('планиран','изпълнен','анулиран') DEFAULT 'планиран',
  `departure_city` varchar(255) NOT NULL,
  `arrival_city` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `flight_number` (`flight_number`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flights`
--

LOCK TABLES `flights` WRITE;
/*!40000 ALTER TABLE `flights` DISABLE KEYS */;
INSERT INTO `flights` VALUES (31,'RY54','2025-04-02 11:30:00','2025-04-02 13:00:00','7','пилоти: Калоян Христов, Петър Петров  стюардеси: Маргарита Димитрова, Силвия Стоянова','планиран','Варна','Будапеща'),(33,'TK1','2025-04-04 20:00:00','2025-04-04 22:20:00','28','пилоти: Филип Филипов, Георги Тодоров стюардеси: Дияна Колева, Тея Пенева','планиран',' София','Мадрид'),(34,'AC33','2025-04-05 04:00:00','2025-04-05 06:00:00','10','Норд Експрес','планиран','Осло','Варна'),(36,'SK50','2025-03-30 10:00:00','2025-03-30 12:30:00','1','пилоти: Иво Андреев, Росен Попов стюардеси: Йоанна Илиева, Симона Николова','изпълнен','Бургас','Стокхолм'),(37,'QR71','2025-03-19 08:00:00','2025-03-19 10:30:00','16','пилоти: Божидар Минчев, Павлин Звездев стюардеси: Катя Тонева, Ива Спасова','изпълнен',' София','Доха'),(38,'UC33','2025-03-10 15:00:00','2025-03-10 16:30:00','19','Баварски моторни заводи АД','изпълнен','Мюнхен','София'),(40,'WS23','2025-04-01 15:00:00','2025-04-01 17:00:00','22','пилоти: Мартин Колев, Светлин Грозданов стюардеси: Емилия Младенова, Христина Русева','анулиран',' София','Дубай'),(41,'EN78','2025-04-07 17:15:00','2025-04-07 18:45:00','20','пилоти: Васил Илиев, Огнян Маринов  стюардеси: Ивайла Рачева, Ина Игнатова ','анулиран','Варна','Варшава'),(42,'SAC100','2025-04-18 11:30:00','2025-04-18 15:30:00','25','Сауди Петрол Карго ЕАД','анулиран','Рияд','Бургас');
/*!40000 ALTER TABLE `flights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passengers`
--

DROP TABLE IF EXISTS `passengers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `passengers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `document_number` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `document_number` (`document_number`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passengers`
--

LOCK TABLES `passengers` WRITE;
/*!40000 ALTER TABLE `passengers` DISABLE KEYS */;
INSERT INTO `passengers` VALUES (17,'Кемал','Сойдере','kemalsoy34@mail.com','Bat_Kemal2@','0893129968','JU0821FD86AG');
/*!40000 ALTER TABLE `passengers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `passenger_id` int NOT NULL,
  `flight_id` int NOT NULL,
  `seat_number` varchar(10) DEFAULT NULL,
  `status` enum('чакаща','потвърдена','анулирана') NOT NULL DEFAULT 'чакаща',
  PRIMARY KEY (`id`),
  UNIQUE KEY `seat_number` (`seat_number`),
  KEY `passenger_id` (`passenger_id`),
  KEY `flight_id` (`flight_id`),
  CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`passenger_id`) REFERENCES `passengers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`flight_id`) REFERENCES `flights` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservations`
--

LOCK TABLES `reservations` WRITE;
/*!40000 ALTER TABLE `reservations` DISABLE KEYS */;
INSERT INTO `reservations` VALUES (7,17,31,'R55','чакаща');
/*!40000 ALTER TABLE `reservations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-27 22:16:37
